﻿// Where our modules wil be stored
window.m = {};

// Window added functions
window.ml = new function () {
    this.itemCallbacks = {};

    /**
     * Checks the URL with the given 'path', and returns if the URL and path match
     * @param {string} path (part of) the url
     * @param {boolean} strict url == path or url.indexOF(path)
     * @returns {boolean} Is the URL
     */
    this.checkURL = function (path, strict = true) {
        var retval = false;

        if (strict)
            retval = location.pathname == path;
        else
            retval = location.pathname.indexOf(path) !== -1;

        return retval;
    };

    // Preparation for the following functions
    this.modules = {};

    /**
     * retrieves a value (async)
     * @param {string} str The parameter to be checked
     * @param {object} callback The callback function to be called when the parameter has updated
     * @param {boolean} liveUpdate Keep running the callback on every update
     */
    this.getItem = function (str, callback, liveUpdate = false) {
        var str_split = str.split('/');
        var refmod = ml.modules;
        var broadcast = false;
        for (var i = 0; i < str_split.length; i++) {
            if (!refmod) {
                broadcast = true;
                break;
            } else if (refmod[str_split[i]] == undefined) {
                broadcast = true;
                break;
            } else {
                refmod = refmod[str_split[i]];
            }
        }
        if (refmod == undefined) broadcast = true;

        if (broadcast) {
            if (callback == null) return null;

            if (ml.itemCallbacks[str] == undefined)
                ml.itemCallbacks[str] = [];

            ml.itemCallbacks[str].push({ liveUpdate: liveUpdate, callback: callback });
        } else {
            if (callback == null) return refmod;
            else callback(refmod)
        }
    };

    /**
     * Updates a value in a shared varsystem
     * @param {string} str The key of the value. Add '/' for subdivision
     * @param {*} val The value that needs to be set
     */
    this.setItem = function (str, val) {
        var str_split = str.split('/');
        var refmod = ml.modules || {};
        var broadcast = false;
        for (var i = 0; i < str_split.length; i++) {
            if (refmod[str_split[i]] == undefined) {
                refmod[str_split[i]] = {};
                broadcast = true;
            }

            if (i == str_split.length - 1)
                refmod[str_split[i]] = val;
            else refmod = refmod[str_split[i]];
        }

        var removelist = [];

        if ((ml.itemCallbacks[str] !== undefined) && (broadcast)) {
            for (var i = 0; i < ml.itemCallbacks[str].length; i++) {
                ml.itemCallbacks[str][i].callback(val);
                if (!ml.itemCallbacks[str][i].liveUpdate) {
                    //removelist.push(ml.itemCallbacks[str][i]);
                    ml.itemCallbacks[str].splice(i, 1);
                    i--;
                }
            }
        }

        for (var i = removelist.length - 1; i >= 0; i--) {
            ml.itemCallbacks[str]
        }
    };

    /**
     * Wait for an element to be loaded
     * @param {string} query CSS-style query
     * @param {object} callback The function that runs when an element is found.
     * @param {integer} interval The ticking time of the check
     */
    this.waitOn = function (query, callback, interval = 100) {
        var int = setInterval(function () {
            var el = document.querySelector(query);
            if (el) {
                callback(el);
                clearInterval(int);
            }
        }, interval);
    };

    /**
     * does a fetch with the given params
     * @param {string} type GET/POST/...
     * @param {string} url URL of the request
     * @param {object} fnDone Function to be ran after the request finished
     * @param {object} headers any headers that need to be present with the request
     */
    function Fetch(type, url, fnDone, headers = {}) {
        function loadOK(res) {
            if (!res.ok) {
                throw Error(res.statusText);
            }
            return res;
        }

        fetch(url, {
            "headers": headers,
            "referrer": "",
            "referrerPolicy": "strict-origin-when-cross-origin",
            "body": null,
            "method": type.toUpperCase(),
            "mode": "cors",
            "credentials": "include"
        }).then(loadOK).then((response) => {
            return response.json();
        }).then(fnDone).catch((e) => {

        });
    };

    /**
     * Performs a GET on the given URL
     * @param {string} url The URL of the request
     * @param {object} headers Any headers that need to be sent along the request
     * @param {object} fnDone Function to run when the request finishes
     */
    this.get = function (url, headers = {}, fnDone) {
        Fetch('get', url, fnDone, headers);
    };

    // vars
    this.getVar = function (key) {
        var item = localStorage.getItem('sh_' + key);
        try {
            item = JSON.parse(item);
        } catch (e) { }
        return item;
    };

    this.setVar = function (key, value) {
        if (typeof value === 'object') value = JSON.stringify(value);
        localStorage.setItem('sh_' + key, value);
    };
};

function styling() {
    // Styling
    if (ml.checkURL('/workorders') || ml.checkURL('/workorders/index', false) || ml.checkURL('workorders/perform', false) || ml.checkURL('/workorders/') || ml.checkURL('/workorders//', false)) {
        try {
            let style = document.createElement('style');
            style.textContent = `
                    .page-content { background-color: rgb(238, 240, 248); }
                    .header { background-color: rgb(30, 30, 45); }
                    .page-container { background-color: rgb(30, 30, 45); }
                    .page-sidebar-menu > li { background-color: rgb(30, 30, 45); }
                    .page-sidebar { background-color: rgb(30, 30, 45); }
                    body { background-color: rgb(30, 30, 45); }
                    .portlet.box.green { border: none; }
                    .page-sidebar { position: fixed; z-index: 99999; }
                `;
            document.body.appendChild(style);
        } catch (e) {
        }
    }

    if (ml.checkURL('/workorders') || ml.checkURL('/workorders/index', false) || ml.checkURL('/workorders/') || ml.checkURL('/workorders//', false)) {
        try {
            let style = document.createElement('style');

            style.textContent = `
                    .row { max-width: 1340px; margin: 0 auto; }
                    .portlet.box.green { background-color: transparent !important; }
                    .portlet.box.green > .portlet-title { background-color: transparent !important; }
                    .portlet.box.green > .portlet-title > .caption { color: rgb(70, 78, 95); margin-left: 14px; }
                    .page-conten. { font-family: Poppins, Helvetica, "sans-serif"; }
                    .portlet.box > .portlet-body { background-color: transparent; padding: 0px; }
                    .btn { border-radius: 6px !important; }
                    .task_fdate { color:red; font-weight: bold; }
                `;
            document.body.appendChild(style);

            document.querySelector('.map-wrap').remove();
            document.querySelector('.page-toolbar > .btn-group > .dropdown-toggle').remove();
            document.querySelector('#spare-parts-list-trigger').style.marginRight = '5px';
        } catch (e) {
        }
    }
}

$(document).ready(function () {
    //view map button
    var mapBtn = $('.map-wrap').remove();
    mapBtn.insertAfter('#btnGroup');
});

window.onload = (event) => {
    let tasks = document.getElementsByClassName('task-item');

    for (let i = 0; i < tasks.length; i++) {
        let clientId = tasks[i].getElementsByClassName('ticket-name-data')[0].textContent.split(' - ')[0].trim();
        let task = '';
        task = i;

        if (task == 0) {
            //insert ants en spot button
            var task_nav = document.getElementsByClassName('task_nav');

            $(task_nav).append(`
            <div class="nav_btn" id="antsBtn"><p onclick="window.open(\`http://ants.inet.telenet.be/tools/modems/modemtest#modem=` + clientId + `\`)">A</p></div>
            <div class="nav_btn" id="spotBtn"><p onclick="window.open(\`https://spot.prd.apps.telenet.be/care/customer/` + clientId + `\`)">S</p></div>`);

            $(task_nav).attr('colspan', 4);
        }
    }
};