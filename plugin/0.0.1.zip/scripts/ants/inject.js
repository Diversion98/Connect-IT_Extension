// ONLY LOADED WHEN TEST IS FINISHED!
setInterval(function() {

jQuery('button[id^="copy-clipboard-button-"]').unbind();
jQuery('button[id^="copy-clipboard-button-"]').click(function() {
    var copyId = $(this).attr('id').replace('copy-clipboard-button-', '');
    var copyData = $('#copy-clipboard-container-'+copyId).text();
    
    const el = document.createElement('textarea');
    el.value = copyData;
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
});

});
