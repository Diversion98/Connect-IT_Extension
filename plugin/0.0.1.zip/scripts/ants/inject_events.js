// Contains info about specific modem events
// Events are gathered on https://docs.google.com/spreadsheets/d/1EfOdVR-h2YiSIEY35DzkwiABINycZdZmE6FcIPjsnPI/edit?usp=sharing

// Export as TSV.
// Open new tab and change source to this:
// <html><body><textarea id="ta"></textarea></body></html>
// then use this to process:
function GenerateTable() {
    var arr = [];
    var items = 'var events = [];\n';
    var lines = document.getElementById('ta').value.split('\n');
    for (var i = 1; i < lines.length; i++) {
        var parts = lines[i].split('\t');
        items += 'events.push({eventId:"'+parts[0]+'", type:"'+parts[1]+'", text:"'+parts[2].split(';')[0]+'", description:"'+parts[3]+'", seenOn:"'+parts[4]+'"});\n';
    }

    document.getElementById('ta').value = items;
}


// Paste result here:



var events = [];
events.push({eventId:"66040100", type:"Information", text:"Authorized", description:"De Authorisatie FSM (Finite State Machine) stuurt dit naar de TEK (Traffic Encryption Key) FSM om aan te geven dan de authorisatie geslaagd is.", seenOn:"43E"});
events.push({eventId:"66040300", type:"Information", text:"Auth Comp", description:"Gezonden door de Authorisatie FSM (Finite State Machine) naar een TEK (Traffic Encryption Key) FSM die de status [Op Reauth Wait] of [Rekey Reauth Wait]. Voorafgegaan door een 'Auth Pend'-event, die niet zichtbaar is.", seenOn:"43E"});
events.push({eventId:"68000100", type:"Critical", text:"", description:"Tijdens de renew voor een nieuw IP-adres werd door de modem geen adres verkregen. Op zich kan dit geen kwaad, een renew wordt uitgevoerd ver voor de leasetijd erop zit.", seenOn:"43E"});
events.push({eventId:"68010100", type:"Error", text:"DHCP RENEW sent - No response for IPv4", description:"Tijdens de renew voor een nieuw IP-adres werd door de modem geen adres verkregen. Op zich kan dit geen kwaad, een renew wordt uitgevoerd ver voor de leasetijd erop zit.", seenOn:"43E"});
events.push({eventId:"69010100", type:"Notice", text:"SW Download INIT - Via NMS", description:"Er word gestart met het downloaden van een update via NMS (Network Management System)", seenOn:"Mercury"});
events.push({eventId:"69011100", type:"Notice", text:"SW download Successful - Via NMS", description:"De modem heeft successvol een update binnengekregen van de NMS (Network Management System)", seenOn:"Mercury"});
events.push({eventId:"73040100", type:"Notice", text:"TLV-11 - unrecognized OID", description:"De configuratie bevat een onleesbare of meerdere vendors. Er wordt aangegeven dat de TLV (Type/Length/Value) de OID (Object Identifier) niet kan lezen. Dit heeft geen gevolgen voor de werking van de modem.", seenOn:"43E"});
events.push({eventId:"82000200", type:"Critical", text:"No Ranging Response received - T3 time-out", description:"De modem heeft in US langer dan 200ms geen respons gehad van de CMTS. Tolereerbaar in kleine aantallen (<25/dag), in grote aantallen is er een US-probleem.", seenOn:"Mercury, 43E"});
events.push({eventId:"82000400", type:"Critical", text:"Received Response to Broadcast Maintenance Request, But no Unicast Maintenance opportunities received - T4 time out", description:"De modem ontvangt geen Station Mantenance Opportunities om een Ranging Request te sturen binnen de T4-timeout peride (+/- 30s). Dit wijst meestal op downstream-problemen, en komt dus voor als langer dan 30s de connectie verloren gaat.", seenOn:"Mercury"});
events.push({eventId:"84000500", type:"Critical", text:"SYNC Timing Synchronization failure - Loss of Sync", description:"De modem ontvangt vanaf de CMTS (Cable Modem Terminal Server) 'SYNC'-pakketten met de exacte tijdsnotatie in. Deze worden in DS aangeboden. Als er meerdere van deze meldingen zijn gaat het om een DS probleem.", seenOn:"Mercury"});
events.push({eventId:"82001100", type:"Warning", text:"RNG-RSP CCAP Commanded Power Exceeds Value Corresponding to the Top of the DRW", description:"De CCAP (Converged Cable Access Platform) vraagt de modem om een US-kanaal uit te zenden boven de DRW (Dynamic Range Window), die een max verschil heeft van 12dB. De modem negeert de waarde en probeert een voorgaande waarde te blijven gebruiken. Indien dit niet lukt wordt de onderste waarde van de DRW gehanteerd en gaat de CM zelf zoeken achter de geschikte waarde. Dit zou niets te maken hebben met US-problemen op de kabel", seenOn:"DOC3.1"});
events.push({eventId:"84020200", type:"Warning", text:"Lost MDD Timeout", description:"MDD (Mac Domain Descriptor)-pakketten bevatten info voor de modem, zoals primary channel en mogelijke kanalen. Dit wordt om de 2s via DS tot bij de modem gestuurd. Als er veel van deze meldingen zijn kan dat wijzen op DS-problemen.", seenOn:"Mercury"});
events.push({eventId:"90000000", type:"Warning", text:"MIMO Event MIMO: Stored MIMO=-1 post cfg file MIMO=-1", description:"MIMO staat voor MDD IP Mode Override. De CMTS (Cable Modem Termnation System) stuurt via de MDD (Mac Domain Descriptor) via welk IP protocol de modem moet verbinden. Deze melding komt voor als de modem ineens een andere waarde doorkrijgt via de TLV (Type/Length/Value). Normaal geeft dit geen problemen, maar dit kan ook wijzen op een reset.", seenOn:"DOC3.1"});
events.push({eventId:"2223898632", type:"Notice", text:"Cable Modem Reboot due to T4 timeout", description:"Modem herstart door een  T4-timeout (+/- 30s). Wijst vaak op DS-problemen.", seenOn:"43E"});
events.push({eventId:"2223898633", type:"Notice", text:"REGISTRATION COMPLETE - Waiting for Operational status", description:"De modem heeft contact kunnen leggen met de CMTS (Cable Modem Termination System) en is bijna opgestart. Dit zie je na een herstart van het registratieproces (contactlegging met Telenet)", seenOn:"43E"});
events.push({eventId:"2333343746", type:"Notice", text:"IP Flood - SRC=27.115.124.75 MAC=00:17:10:88:BB:C8", description:"Er werd een scan gedetecteerd naar open poorten. Heel vaak gaat het daarbij om hackers die proberen binnen te geraken.", seenOn:"Mercury"});
events.push({eventId:"2333343747", type:"Notice", text:"Illegal - Dropped FORWARD packet: SRC=192.168.0.2 MAC=D4:CA:6D:6E:82:29", description:"De Interne firewall kon het pakket niet uitsturen door een US-error. Zie je meestal samen met T3-timeouts.", seenOn:"Mercury"});
events.push({eventId:"2333343748", type:"Notice", text:"REGISTRATION COMPLETE - Waiting for Operational status", description:"De modem heeft contact kunnen leggen met de CMTS (Cable Modem Termination System) en is bijna opgestart. Dit zie je na een herstart van het registratieproces (contactlegging met Telenet)", seenOn:"Mercury"});
events.push({eventId:"2333343749", type:"Notice", text:"Reset to Factory defaults initiated by SNMP", description:"Fabrieksinstellingen werden geladen vanaf de SNMP (Simple Network Management Protocol). Alle logs en levels voor deze datum zijn helaas verdwenen.", seenOn:"Mercury"});
events.push({eventId:"2333343752", type:"Notice", text:"Cable Modem Reboot - SNMPA_CreateSocketEntry IPv4 : Cannot bind SNMP server socket", description:"Kan geen verbinding worden gemaakt met de SNMP (Simple Network Management Protocol)  server. De modem gaat hierdoor rebooten", seenOn:"Mercury"});
events.push({eventId:"2333343752", type:"Notice", text:"Cable Modem Reboot - due to power reset", description:"De modem is zonder stroom gevallen, en moest daardoor herstarten. Dit kan gaan over het uittrekken door de klant, maar ook een voedingsprobleem, of een intern voedingsprobleem in de modem.", seenOn:"Mercury"});
events.push({eventId:"2333343752", type:"Notice", text:"Cable Modem Reboot from SNMP", description:"De modem werd herstart via de SNMP (Simple Network Management Protocol), afkomstig van Telenet.", seenOn:"Mercury, 43E"});
events.push({eventId:"2333343752", type:"Notice", text:"Cable Modem Reboot - Can not find CBN_TEST_IPTABLE chain", description:"Voor zover ik kan vinden lijkt dit een reboot te zijn door problemen met onderdeel van een certificaat of beveiliging.", seenOn:"Mercury"});
events.push({eventId:"2333343752", type:"Notice", text:"Cable Modem Reboot - dual boot reset indication", description:"Diverse dingen lopen verkeerd op hard- en softwarevlak. Modem is defect.", seenOn:"Mercury"});





// Functions
var rows = $('#eventLog tbody tr');
for (var i = 0; i < rows.length; i++) {
    var id = rows[i].children[4].textContent;
    var item = rows[i].children[5];
    var possibleItems = [];

    for (var j = 0; j < events.length; j++) {console.log(events[j].eventId + ' /\ ' + id);
        if (events[j].eventId == id)
            possibleItems.push(events[j]);
    }

    // When multiple are possible (multiple events share the eventId)
    if (possibleItems.length !== 1) {
        for (var j = 0; j < possibleItems; j++) {
            if (possibleItems.text == item)
                possibleItems = possibleItems.splice(j,1);
        }
    }

    console.log(possibleItems);
    
    rows[i].children[4].setAttribute('class', 'help');
    if (possibleItems.length !== 0)
        rows[i].children[4].setAttribute('title', possibleItems[0].description);
    else
        rows[i].children[4].setAttribute('title', 'Voorlopig onbekend.');
}