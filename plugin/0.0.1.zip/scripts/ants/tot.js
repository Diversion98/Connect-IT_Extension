// Techs of tomorrow .js

var settings = {};

chrome.storage.sync.get({
    ants_levelsswitch: true,
    ants_addeventlog: true,
    ants_autoenter: true,
    ants_antscopy_compactcopy: false,
    ants_eventloglayout: false
}, function(items) {
    settings = items;

    $(document).ready(function() {
        if ((settings.ants_eventloglayout) && (window.location.href.indexOf('ants.inet.telenet.be/tools/modems/eventlog/') !== -1)) {
            setInterval(function() {
                if ($('#eventLog thead th').length == 6) {
                    // set up headers
                    $('#eventLog thead tr').append('<th>CM-MAC</th><th>CMTS-MAC</th><th>CM-QOS</th><th>CM-VER</th>');

                    var rows = $('#eventLog tbody tr');

                    for (var i = 0; i < rows.length; i++) {
                        var parts = $('td', rows[i])[5].textContent.split(';');
                        $('td', rows[i])[5].textContent = parts[0];
                        var headers = {};
                        for (var j = 0; j < parts.length; j++) {
                            var lp = parts[j].split('=');
                            if (lp.length == 2) {
                                headers[lp[0]] = lp[1];
                            }
                        }
                        var h = {};
                        if (headers['CM-MAC'] == undefined) h['CM-MAC'] = ''; else h['CM-MAC'] = headers['CM-MAC'];
                        if (headers['CMTS-MAC'] == undefined) h['CMTS-MAC'] = ''; else h['CMTS-MAC'] = headers['CMTS-MAC'];
                        if (headers['CM-QOS'] == undefined) h['CM-QOS'] = ''; else h['CM-QOS'] = headers['CM-QOS'];
                        if (headers['CM-VER'] == undefined) h['CM-VER'] = ''; else h['CM-VER'] = headers['CM-VER'];
                        $(rows[i]).append('<td>'+h['CM-MAC']+'</td><td>'+h['CMTS-MAC']+'</td><td>'+h['CM-QOS']+'</td><td>'+h['CM-VER']+'</td>');
                    }

                    // Inject events
                    if ($('#scr_events').length == 0) {
                        var tag = document.createElement("script");
                        tag.setAttribute('id', 'scr_events');
                        tag.setAttribute('src', 'chrome-extension://'+chrome.runtime.id+'/plugins/ants/inject_events.js');
                        document.body.appendChild(tag);
                    }
                }
            }, 1000);
        }
    });
});

$(document).ready(function() {
    // Auto-start testing
    if ((document.location.href.indexOf('tools/modems/modemtest') != -1) &&
        (settings.ants_autoenter)) {
        setTimeout(function() {
            if ($('#modem').val().length > 2) {
                $('#start-test').click();
            }
        }, 500);
    } else if ((document.location.href.indexOf('tools/modems/levels') != -1) &&
    (settings.ants_autoenter)) {
        if ($('#modem-input').val().length > 2) {
            setTimeout(function() {
                //$('#table-button').css('margin-right: 400px;');
                $('body').append('<div id="stretch"></div>');
                $('#stretch').css('width', '100%').css('height', '1px');
                $('#chart-button').click();
            }, 1000);
        }
    }

    // Level history
    if (document.location.href.indexOf('tools/modems/modemtest') != -1) {
        setInterval(function() {
            if ($('#tab-levels').length !== 0) {
                var mac = $('#param-cmMacAddress').text();
                // Show level history as an iframe to the test
                if (($('#ants-army-levels').length === 0) && (settings.ants_levelsswitch)) {
                    // Tab levels shown
                    $('#tab-levels').html('<iframe id="ants-army-levels" style="width:100%;height:800px;border:none;margin-left:-10px;margin-top:0px;" src="http://ants.inet.telenet.be/tools/modems/levels/'+mac+'?framed=true"></iframe>');
                }

                // +Tab Event log
                if (($('#tab-eventlog').length === 0) && (settings.ants_addeventlog)) {
                    $($('#tabs ul')[0]).append('<li class="ui-state-default ui-corner-top ui-tabs-tab ui-tab" role="tab" tabindex="-1" aria-controls="tab-eventlog" aria-labelledby="ui-id-100" aria-selected="false"><a href="#tab-eventlog" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="ui-id-100">Event Log</a></li>');
					
                    $('#tabs').append('<div id="tab-eventlog" aria-labelledby="ui-id-100" class="ui-tabs-panel ui-widget-content ui-corner-bottom" role="tabpanel" aria-expanded="false" aria-hidden="true" style="display:none;"><iframe style="width:100%;height:800px;border:none;margin-left:-10px;margin-top:0px;" src="http://ants.inet.telenet.be/tools/modems/eventlog/'+mac+'?framed=true"></iframe></div>');
					$('body').append('<script>$("#tabs").tabs( "refresh" );</script>');
                }

                // Overwrite copy function that 'does not work'
                // Has to be embedded in the page
                if ($('button[id^="copy-clipboard-button-"]').length !== 0) {
                    if ($('#scr_copy').length == 0) {
                        var tag = document.createElement("script");
                        tag.setAttribute('id', 'scr_copy');
                        tag.setAttribute('src', 'chrome-extension://'+chrome.runtime.id+'/plugins/ants/inject.js');
                        document.body.appendChild(tag);
                    }

                    var attr = document.getElementById('copy-clipboard-button-copyData').getAttribute('aria-describedby');


                    setInterval(function() {
                        if (document.getElementById(attr) !== null) {
                            document.getElementById(attr).remove();
                        }
                    }, 100);
                }

                // Antscopy Compact Log
                if (($('#copyData').attr('modified') !== 'true') && (settings.ants_antscopy_compactcopy)) {
                    // Copy Paste right from antscopy
                    var spacing = 6;
                    var texty = "";
                    //mac,model,versie
                    var mac = 
                    $("#tab-CM th").filter(function() {
                            return $(this).text() == "MAC adres";
                    }).closest('th').siblings().eq(0).text();
                    var model = 
                    $("#tab-CM th").filter(function() {
                        return $(this).text() == "Model";
                    }).closest('th').siblings().eq(0).text();
                    var node = 
                    $("#tab-Status th").filter(function() {
                    return $(this).text() == "Node (Ninas)";
                    }).closest('th').siblings().eq(0).text();
                    var router = 
                    $("#tab-CMTS th").filter(function() {
                    return $(this).text() == "Naam";
                    }).closest('th').siblings().eq(0).text();
                    var software = 
                    $("#tab-CM th").filter(function() {
                    return $(this).text() == "Software";
                    }).closest('th').siblings().eq(0).text();
                    var ipadres = 
                    $("#tab-CM th").filter(function() {
                    return $(this).text() == "IP adres";
                    }).closest('th').siblings().eq(0).text();
                    var powerup = 
                    $("#tab-Status th").filter(function() {
                    return $(this).text() == "Power-up tijd";
                    }).closest('th').siblings().eq(0).text();
                    var registratie = 
                    $("#tab-Status th").filter(function() {
                    return $(this).text() == "Registratie tijd";
                    }).closest('th').siblings().eq(0).text();
                    texty   += "Mac\xa0\xa0\xa0\xa0" + mac +" ("+model+")\n"
                    + "Node\xa0\xa0\xa0"+ node+ "\n"
                    + "Router\xa0"+ router +"\n"
                    + "Softw\xa0\xa0"+ software +"\n"
                    + "WanIP\xa0\xa0"+ ipadres + "\n" 
                    + "Power\xa0\xa0"+ powerup + "\n"
                    + "Regis\xa0\xa0"+registratie+"\n\n"       
                    //tx
                    texty += "Freq\xa0";
                    tableRow = $("#tab-RF-US th").filter(function() {
                        return $(this).text() == "Frequentie (MHz)";
                    }).closest('tr');
                    $(tableRow).find('td').each(function() {
                        var choptext = $(this).text();
                        var count = choptext.length;
                        total = spacing - count;
                        texty += choptext;  
                        for (i=0; i < total; i++) texty += "\xa0";
                    });
                    texty += "\nTX\xa0\xa0\xa0";
                    tableRow = $("th").filter(function() {
                        return $(this).text() == "Tx Level (dBmV)";
                    }).closest('tr');
                    $(tableRow).find('td').each(function() {
                        var count = $(this).text().length;
                        total = spacing - count;
                        texty += $(this).text();  
                        for (i=0; i < total; i++) texty += "\xa0";
                    });
                    texty += "\n\nFreq\xa0";
                    tableRow = $("#tab-RF-DS th").filter(function() {
                    return $(this).text() == "Frequentie (MHz)";
                    }).closest('tr');
                    $(tableRow).find('td').each (function() {
                    var choptext = $(this).text();
                        var count = choptext.length;
                        total = spacing - count -1;
                        texty += choptext;  
                        for (i=0; i < total; i++) texty += "\xa0";
                    });
                    texty += "\nRX\xa0\xa0\xa0";
                    tableRow = $("th").filter(function() {
                        return $(this).text() == "Rx Level (dBmV)";
                    }).closest('tr');
                    $(tableRow).find('td').each (function() {
                    //joeyTx
                    var count = $(this).text().length;
                    total = spacing - count -1;
                    texty += $(this).text();  
                    for (i=0; i < total; i++) texty += "\xa0";
                    });
                    texty += "\nSNR\xa0\xa0";
                    tableRow = $("#tab-RF-DS th").filter(function() {
                        return $(this).text() == "SNR";
                    }).closest('tr');
                    $(tableRow).find('td').each(function() {
                        var count = $(this).text().length;
                        total = spacing - count -1;
                        texty += $(this).text();  
                        for (i=0; i < total; i++) texty += "\xa0";
                    });
                    texty += "\n\n";
                    // End of Copy-Paste
                    $('#copyData').text(texty);console.log('PASTED');
                    $('#copyData').attr('modified', 'true');
                }
            }
        }, 1000);
    }

    // Deleting headers and unneeded stuff for frames
    if (document.location.href.indexOf('tools/modems') != -1) {
        var url = new URL(window.location.href);
        if (url.searchParams.get("framed") == 'true') {
            $($('h1')[0]).hide();
            $('#header').hide();
            $('#footer').hide();
            $('#content').css('margin-top', '-10px');
            $('body').css('width', '100%');
            $('body').css('background', 'white');
            $('#result').css('width', '100%');
			setInterval(function() {
				$($('#message-dialog-helper').parent()).css('top', '10px');
				$($('#message-dialog-helper').parent()).css('left', '10px');
			}, 1000);

            
            if (document.location.href.indexOf('tools/modems/eventlog') != -1) {
                $('#start-test').click();
            }
        }
    }

    // Take hashed url-params and fill corresponding inputs
    var hashParams = window.location.hash.substr(1).split('&'); // substr(1) to remove the `#`
    if (hashParams[0] != '') {
        for (var i = 0; i < hashParams.length; i++){
            var p = hashParams[i].split('=');
            document.getElementById(p[0]).value = decodeURIComponent(p[1]);
        }
    }
});

