//auto login for sfx
var count = 0;

$(document).ready(function () {
    if (count == 0) {
        var username = "dylan.vannuffel@unit-t.eu";
        var password = "PINcode=6119&";
        document.getElementById("UserUsername").value = username;
        document.getElementById("input-type-password").value = password;
        var button = document.getElementById("btnLogin")
        button.click();
        count++;
    }
});